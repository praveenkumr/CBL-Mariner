---
title: "YAML: does it fit in Markdown?"
author: test
tags:
- yaml
- markdown
wrappedtext: >
 this is really a
 single line of text
 despite appearances
include_newlines: |
 exactly as you see
 will appear these three
 lines of poetry
people:
  - 
    name: John D'vloper
    job: Developer
    hobbies:
      - Amateur radio
      - Pet adoption & fostering
      - Puzzle
  - 
    name: Tabitha Bitumen
    job: Developer
    hobbies:
      - Ice skating
      - Water polo
      - Caving
---

# YAML: does it fit in Markdown?

Lots of Static Site Generators like Jekyll, Hugo, Lektor and more use
a standard format: Markdown with YAML Front Matter.

Why
---

Because blog posts need metadata!

