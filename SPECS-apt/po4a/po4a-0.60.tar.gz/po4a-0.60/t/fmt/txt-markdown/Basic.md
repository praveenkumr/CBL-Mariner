% The document title
% The document first author; The document second author

A nice title
============

The first paragraph.

The second paragraph.

 * Some bullet point
 * Another bullet point with a second line, which is so long that it should
   get wrapped by the output of po4a
 * A third bullet point

# Another title with different markup

## Subtitle

And more text in a paragraph.
